#include "DKPPlugin.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#define DATABASEFILE		"tidedkp.txt"
#define TELLHEADERLENGTH	25	
#define MYDKPCOMMAND		"!dkp"
#define SHOWDKPCOMMAND		"!showdkp"

//===========================================================================
DKPPlugin::DKPPlugin(CEQIMConsole* C)
{
	loadDatabase();
	_Console = C;
}

//===========================================================================
DKPPlugin::~DKPPlugin()
{
}

//===========================================================================
void DKPPlugin::parseMessage(char* _msg)
{
	if (strstr (_msg,"PRIVATE from"))
	{
		if (strstr (_msg,MYDKPCOMMAND) )
		{
			sendDkp(_msg);
		}
		if (strstr (_msg,SHOWDKPCOMMAND) )
		{
			sendShowDkp(_msg);
		}
	}
}

//===========================================================================
void DKPPlugin::getNameFromTell(char* _Name, char* _Tell)
{
	strcpy(_Name,_Tell + TELLHEADERLENGTH);

	for(int i=0; i < strlen(_Name) ;i++)
		if ((_Name[i]==20) || (_Name[i]==10) || (_Name[i]=='-'))
			_Name[i]=0;

	strcpy( _Name, strrchr(_Name,'.')+1 );
}

//===========================================================================
void DKPPlugin::getOption(char* _Name, char* _Line, char* _Option)
{
	strcpy(_Name,strstr(_Line,_Option)+ strlen(_Option) +1);

	for(int i=0; i < strlen(_Name) ;i++)
		if (_Name[i]=='\n')
			_Name[i]=0;
}

//===========================================================================
void DKPPlugin::sendDkp(char* _Line)
{
	char cAsker[60];
	char cName[60];
	char cAnswer[256];
	int i;

	getNameFromTell(cAsker, _Line);
	strcpy(cName, cAsker);

	getDKP(cAsker, cName);

	sprintf(cAnswer, ";2 [GroupBot] [%s] request DKP", cAsker);
	_Console->ChatCommand(cAnswer);
}

//===========================================================================
void DKPPlugin::sendShowDkp(char* _Line)
{
	char cAsker[60];
	char cName[60];
	char cAnswer[256];

	getNameFromTell(cAsker, _Line);
	getOption(cName, _Line, SHOWDKPCOMMAND);

	getDKP(cAsker, cName);

	sprintf(cAnswer, ";2 [GroupBot] [%s] request DKP", cAsker);
	_Console->ChatCommand(cAnswer);
}


//===========================================================================
void DKPPlugin::loadDatabase()
{
	int iLength=0;
	printf("DKPPlugin loading database, please wait.\n");
	FILE *file=fopen(DATABASEFILE,"r");

	if (!file)
		return;

	char line[256];

	pointDataBase.clear();

	while(fgets(line, 256, file) != NULL)
	{
		for(int i=0; i< strlen(line); i++)
		{
			if (line[i]=='\n')
			{
				line[i] = 0; 
				break; 
			}
		}
		pointDataBase.push_back(line);
		iLength++;
	}

	fclose(file);
	printf("Database Loaded : %d items in memory!... \n", iLength);
}

//===========================================================================
void DKPPlugin::getDKP(char* asker, char* _stofind)
{
	string AskerName(asker);
	string result = "";
	string tellheader = ";tell " + AskerName + " [GroupBot]";

	for(int i=0; i < pointDataBase.size(); i++)
	{
		string& sT = pointDataBase.at(i);

		int num = sT.find(_stofind, 0);

		if ( num >= 0 )
		{
			result = tellheader + sT;
			_Console->ChatCommand(result.c_str());

			return;
		}
	}

	result = tellheader + " no DKP info found";
	_Console->ChatCommand(result.c_str());

	return;
}